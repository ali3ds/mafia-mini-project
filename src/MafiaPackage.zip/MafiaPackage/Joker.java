package MafiaPackage;

public class Joker extends person {
	public Joker(String name) {
		this.name=name;
	}
	
}
