package MafiaPackage;

public class godfather  extends person {
	public godfather(String name) {
		this.name=name;
		this.hasToWakeUp=true;
	}
}
