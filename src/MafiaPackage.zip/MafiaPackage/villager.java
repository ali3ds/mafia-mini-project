package MafiaPackage;

public class villager  extends person {
	public villager(String name) {
		this.name=name;
	}
}
