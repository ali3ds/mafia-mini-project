package MafiaPackage;

public class mafia extends person  {
	public mafia(String name) {
		this.name=name;
		this.hasToWakeUp=true;
	}
}
