package MafiaPackage;

public class silencer extends person  {
	public silencer(String name) {
		this.name=name;
		this.hasToWakeUp=true;
	}
}
