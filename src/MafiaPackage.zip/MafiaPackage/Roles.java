package MafiaPackage;

public enum Roles {

}
