package MafiaPackage;

public class detective  extends person {
	public detective(String name) {
		this.name=name;
		this.hasToWakeUp=true;
	}
}
