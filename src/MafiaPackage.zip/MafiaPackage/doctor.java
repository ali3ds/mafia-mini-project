package MafiaPackage;

public class doctor  extends person {
	public doctor(String name) {
		this.name=name;
		this.hasToWakeUp=true;
	}
	public void rescue() {
		
	}
}
