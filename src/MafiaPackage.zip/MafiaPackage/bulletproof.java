package MafiaPackage;

public class bulletproof extends person {

	boolean extraHealth=true;
	public bulletproof(String name) {
		this.name=name;
	}
}
